# SevaTechBihar — Backend + Admin

Yeh ek real Node.js server hai (koi external npm package nahi lagti). Content
`db.json` file mein save hota hai — jab admin login karke edit + save karta
hai, sabhi visitors ko naya content dikhta hai.

## Admin Login (default)
- Username: `admin`
- Password: `SevaTech@2026`

Password badalne ke liye niche "Password Badlein" section dekhein.

## 1. Apne computer par test karein

Zaroorat: [Node.js](https://nodejs.org) installed ho (v18 ya upar).

```
cd sevatechbihar-backend
node server.js
```

Browser mein kholein: **http://localhost:3000**

## 2. Free mein internet par live karein (koi credit card nahi chahiye)

**Render.com** sabse aasan hai:

1. [render.com](https://render.com) par free account banayein
2. Is poori `sevatechbihar-backend` folder ko GitHub par ek naye repository
   mein upload karein
3. Render dashboard mein **New → Web Service** par click karein, apna GitHub
   repo select karein
4. Settings:
   - **Build Command:** (khaali chhod dein)
   - **Start Command:** `node server.js`
5. **Create Web Service** dabayein — kuch minute mein aapki website live ho
   jayegi, jaise: `https://sevatechbihar.onrender.com`

Baad mein apna khud ka domain (sevatechbihar.com) is Render URL se connect
kar sakte hain (Render ke "Custom Domain" setting se).

**Railway.app** bhi isi tarah kaam karta hai, agar Render pasand na aaye.

## Password Badlein

1. Terminal mein yeh command chalayein (naya password apni marzi se
   `MeraNayaPassword` ki jagah likhein):

```
node -e "
const crypto = require('crypto');
const salt = crypto.randomBytes(16).toString('hex');
const hash = crypto.scryptSync('MeraNayaPassword', salt, 64).toString('hex');
console.log(JSON.stringify({salt, hash}));
"
```

2. Jo `salt` aur `hash` milega, use `db.json` file ke `"admin"` section mein
   paste kar dein.

## Yeh "database" kitni mazboot hai

`db.json` ek simple file hai — chhoti website (ek certificate/job list) ke
liye bilkul theek hai. Agar aage chal kar bahut zyada traffic ya bahut
zyada data (jaise har user ka apna account) chahiye ho, tab real database
(jaise PostgreSQL ya MongoDB) mein upgrade karna sahi rahega — woh alag se
bana sakte hain.

## Security note

- Password server par hash (encrypted form) mein hi store hota hai, plain
  text mein kahin nahi.
- Login session sirf 12 ghante tak valid rehta hai.
- HTTPS zaroor use karein jab live karein (Render/Railway apne aap HTTPS
  deta hai) — bina HTTPS ke login password network par saaf dikh sakta hai.
