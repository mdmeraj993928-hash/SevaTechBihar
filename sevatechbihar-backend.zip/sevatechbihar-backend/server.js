const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, "db.json");
const PUBLIC_DIR = path.join(__dirname, "public");

// ---- tiny in-memory session store (token -> {username, expires}) ----
const sessions = new Map();
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
}
function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function verifyPassword(password, salt, storedHash) {
  const hash = crypto.scryptSync(password, salt, 64);
  const stored = Buffer.from(storedHash, "hex");
  if (hash.length !== stored.length) return false;
  return crypto.timingSafeEqual(hash, stored);
}

function getBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

function sendJSON(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
  });
  res.end(body);
}

function getToken(req) {
  const auth = req.headers["authorization"] || "";
  const match = auth.match(/^Bearer (.+)$/);
  return match ? match[1] : null;
}

function requireAuth(req) {
  const token = getToken(req);
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expires) {
    sessions.delete(token);
    return null;
  }
  return session;
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".xml": "application/xml",
  ".txt": "text/plain; charset=utf-8",
};

function serveStatic(req, res, urlPath) {
  let filePath = urlPath === "/" ? "/index.html" : urlPath;
  filePath = path.join(PUBLIC_DIR, filePath);

  // prevent path traversal outside /public
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      return res.end("Not found");
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;

  try {
    // ---- GET /api/content : public, returns hero/certificates/jobs ----
    if (pathname === "/api/content" && req.method === "GET") {
      const db = readDB();
      return sendJSON(res, 200, {
        hero: db.hero,
        certificates: db.certificates,
        jobs: db.jobs,
      });
    }

    // ---- POST /api/login : {username, password} -> {token} ----
    if (pathname === "/api/login" && req.method === "POST") {
      const body = await getBody(req);
      const db = readDB();
      const { username, password } = body;
      if (
        username === db.admin.username &&
        password &&
        verifyPassword(password, db.admin.salt, db.admin.hash)
      ) {
        const token = crypto.randomBytes(24).toString("hex");
        sessions.set(token, { username, expires: Date.now() + SESSION_TTL_MS });
        return sendJSON(res, 200, { token });
      }
      return sendJSON(res, 401, { error: "Galat username ya password." });
    }

    // ---- POST /api/logout ----
    if (pathname === "/api/logout" && req.method === "POST") {
      const token = getToken(req);
      if (token) sessions.delete(token);
      return sendJSON(res, 200, { ok: true });
    }

    // ---- PUT /api/content : protected, saves hero/certificates/jobs ----
    if (pathname === "/api/content" && req.method === "PUT") {
      const session = requireAuth(req);
      if (!session) return sendJSON(res, 401, { error: "Login required." });
      const body = await getBody(req);
      const db = readDB();
      if (body.hero) db.hero = body.hero;
      if (Array.isArray(body.certificates)) db.certificates = body.certificates;
      if (Array.isArray(body.jobs)) db.jobs = body.jobs;
      writeDB(db);
      return sendJSON(res, 200, { ok: true });
    }

    // ---- everything else: static files from /public ----
    if (req.method === "GET") {
      return serveStatic(req, res, pathname);
    }

    sendJSON(res, 404, { error: "Not found" });
  } catch (err) {
    sendJSON(res, 500, { error: "Server error: " + err.message });
  }
});

server.listen(PORT, () => {
  console.log(`SevaTechBihar backend chal raha hai: http://localhost:${PORT}`);
});
