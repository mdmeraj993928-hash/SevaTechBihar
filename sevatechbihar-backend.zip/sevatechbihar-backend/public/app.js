let authToken = null; // session-only; resets on page refresh by design
let siteData = { hero: {}, certificates: [], jobs: [] };

document.getElementById('navToggle').addEventListener('click', function () {
  document.getElementById('navLinks').classList.toggle('open');
});

function certCardHTML(item) {
  return `
    <div class="card" data-id="${item.id}">
      <h3 data-field="title">${item.title}</h3>
      <p class="desc" data-field="description">${item.description}</p>
      <a class="official-link" data-field="link" href="${item.link}" target="_blank" rel="noopener">Official Website Kholein →</a>
      <span class="url-tag" data-field="urlTag">${item.urlTag}</span>
    </div>`;
}
function jobCardHTML(item) {
  return `
    <div class="card job" data-id="${item.id}">
      <h3 data-field="title">${item.title}</h3>
      <p class="desc" data-field="description">${item.description}</p>
      <a class="official-link" data-field="link" href="${item.link}" target="_blank" rel="noopener">Official Website Kholein →</a>
      <span class="url-tag" data-field="urlTag">${item.urlTag}</span>
    </div>`;
}

function render() {
  document.getElementById('heroTitle').textContent = siteData.hero.title || '';
  document.getElementById('heroSubtitle').textContent = siteData.hero.subtitle || '';
  document.getElementById('certGrid').innerHTML = siteData.certificates.map(certCardHTML).join('');
  document.getElementById('jobGrid').innerHTML = siteData.jobs.map(jobCardHTML).join('');
}

async function loadContent() {
  const res = await fetch('/api/content');
  siteData = await res.json();
  render();
}
loadContent();

// ---- Admin login ----
const loginModal = document.getElementById('loginModal');
const adminBar = document.getElementById('adminBar');
const loginError = document.getElementById('loginError');
const saveToast = document.getElementById('saveToast');

document.getElementById('adminLoginLink').addEventListener('click', function (e) {
  e.preventDefault();
  loginModal.classList.add('open');
});
document.getElementById('cancelLogin').addEventListener('click', function () {
  loginModal.classList.remove('open');
  loginError.style.display = 'none';
});

document.getElementById('submitLogin').addEventListener('click', async function () {
  const username = document.getElementById('userInput').value.trim();
  const password = document.getElementById('passInput').value;
  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) throw new Error();
    const data = await res.json();
    authToken = data.token;
    loginModal.classList.remove('open');
    loginError.style.display = 'none';
    enableEditMode();
  } catch (e) {
    loginError.style.display = 'block';
  }
});

function enableEditMode() {
  adminBar.classList.add('open');
  document.querySelectorAll('#heroTitle, #heroSubtitle, .card [data-field]').forEach(function (el) {
    el.setAttribute('contenteditable', 'true');
  });
}
function disableEditMode() {
  adminBar.classList.remove('open');
  document.querySelectorAll('[contenteditable="true"]').forEach(function (el) {
    el.removeAttribute('contenteditable');
  });
}

document.getElementById('logoutBtn').addEventListener('click', async function () {
  if (authToken) {
    await fetch('/api/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + authToken } });
  }
  authToken = null;
  disableEditMode();
});

function collectDataFromDOM() {
  const hero = {
    title: document.getElementById('heroTitle').textContent.trim(),
    subtitle: document.getElementById('heroSubtitle').textContent.trim(),
  };
  const certificates = Array.from(document.querySelectorAll('#certGrid .card')).map(function (card) {
    return {
      id: card.getAttribute('data-id'),
      title: card.querySelector('[data-field="title"]').textContent.trim(),
      description: card.querySelector('[data-field="description"]').textContent.trim(),
      link: card.querySelector('[data-field="link"]').getAttribute('href'),
      urlTag: card.querySelector('[data-field="urlTag"]').textContent.trim(),
    };
  });
  const jobs = Array.from(document.querySelectorAll('#jobGrid .card')).map(function (card) {
    return {
      id: card.getAttribute('data-id'),
      title: card.querySelector('[data-field="title"]').textContent.trim(),
      description: card.querySelector('[data-field="description"]').textContent.trim(),
      link: card.querySelector('[data-field="link"]').getAttribute('href'),
      urlTag: card.querySelector('[data-field="urlTag"]').textContent.trim(),
    };
  });
  return { hero, certificates, jobs };
}

function showToast(msg) {
  saveToast.textContent = msg;
  saveToast.classList.add('show');
  setTimeout(function () {
    saveToast.classList.remove('show');
  }, 2500);
}

document.getElementById('saveBtn').addEventListener('click', async function () {
  if (!authToken) return showToast('Pehle login karein.');
  const payload = collectDataFromDOM();
  try {
    const res = await fetch('/api/content', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + authToken },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error();
    siteData = payload;
    showToast('✓ Save ho gaya — sabhi visitors ko naya content dikhega.');
  } catch (e) {
    showToast('Save nahi hua, dobara try karein.');
  }
});
